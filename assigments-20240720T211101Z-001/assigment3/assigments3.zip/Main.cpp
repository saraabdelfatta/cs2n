#include "Stack.cpp"
#include <cmath>

int main() {
	ifstream read;
	read.open("cities11.txt");
	
	int tmp;
	int N = 0;
	while(read >> tmp)
		N++;
	
	N = sqrt(N);
	
	read.close();
	
	int A[N][N];
	int v[N];
	
	read.open("cities11.txt");
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
		{
			read >> A[i][j];
		}
	}
	read.close();
	Stack<int> s;
	int k = 0;
	int unsean = 0, hold = 1;
	int i;
	int d = 0;
	for (i = 0; i < N; i++)
	{
		v[i] = unsean;
	}
	s.push(k);
	v[k] = hold;
	while (!s.stacEmpty())
	{
		k = s.pop();
		v[k] = hold;
		cout << k << " ";
		for (int j = 0; j < N; j++)
		{

			if (A[k][j] && v[j] == 0)
			{
				s.push(j);
				v[j] = hold;
				break;
			}
		}
		for (int l = 0; l < k; l++)
		{
			d = d + k;
		}
	}
	cout << " \nthe distance " << d << endl;
	return 0;
}
