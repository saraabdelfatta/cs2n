#include<iostream>
#include<fstream>

using namespace std;

template<class T>
class Stack
{
public:
	//satack ADT
	Stack(int num=15);
	bool stackIsFull() const;
	bool stacEmpty() const;
	T stackTop();
	void push(T x);
	T pop();

	

private:
	T* p;
	int top;
	int MaxSize;
};

