#include "Stack.h"

//cheak if the the sarak is empty or not
template<class T>
Stack<T>::Stack(int num)
{
	MaxSize = num;
	p = new int[MaxSize];
	top = -1;
}

template<class T>
bool Stack<T>::stacEmpty() const
{
	return (top < 0);
}

//cheak if the the sarak is full or not
template<class T>
bool Stack<T>::stackIsFull() const
{
	return (top >= (MaxSize - 1));
}

//to show the top of the stack
template<class T>
T Stack<T>::stackTop()
{
	if (stacEmpty())
		cout << " the Stack is Under flow " << endl;
	
	return p[top];
}

//push
template<class T>
void Stack<T>::push(T x)
{
	if (stackIsFull())
		cout << " the stack is Over flow " << endl;
	else
		p[++top] = x;		//it will increase then it will hold the new value 
}

//pop
template<class T>
T Stack<T>::pop()
{
	if (stacEmpty())
		cout << " Stack is uncer flow " << endl;
	
	return p[top--] ;		// move then decreament
}
